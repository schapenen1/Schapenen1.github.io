class Match {
  PImage image;

  Match () {
    image = loadImage("Fire 1.png");
    if (image == null) {
      print("n");
    }
  }

  void display (float x, float y) {
    fill(255);
    rect(x, y, 10, 50);
    image(image, x-45, y-50, 100, 100);
  }
}
