class Stocking extends Socks {
  Stocking () {
  super();
  }
  void test () {
    print("test");
  }
}
