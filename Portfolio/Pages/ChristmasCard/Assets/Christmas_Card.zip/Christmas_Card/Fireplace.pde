class Background {
  color Mortar = #C1C1BF;
  
  void fireplace () {

    pushMatrix();
    translate(0, 375);
    noStroke();

    // Outer dark ellipse for fireplace
    fill(Mortar);
    ellipse(width/2, height/2.5, 600, 400);

    // Inner lighter ellipse for depth
    fill(30);
    ellipse(width/2, height/2.3, 600, 400);

    // Firewood
    fill(#553F16, 250);
    ellipse(width/2, 385, 240, 40);

    popMatrix(); 
  }
  int brickHeight = 20;
  int brickWidth = 40;
  
  color Brick = #AF5A39;

  void bricks() {
    stroke(1);
    pushMatrix();
    translate(0, 375);

    // Mortar
    fill(Mortar);
    rect(0, 0, width, height - 375);

    // Bricks
    for (int brickY = 0; brickY < 750 - 375; brickY += 25) {
      for (int brickX = 0; brickX < width; brickX += brickWidth + 5) {
        fill(Brick);
        if ((brickY / 25) % 2 == 0) {
          rect(brickX, brickY, brickWidth, brickHeight);
        } else {
          rect(brickX - (brickWidth / 2), brickY, brickWidth, brickHeight);
        }
      }
    }
    noStroke();
    popMatrix();
  }
  //Shelf
 void shelf () {
   fill(#6C5B2B);
   stroke(0);
   strokeWeight(1);
   rect(0, 365, 500, 40);
 }
}
