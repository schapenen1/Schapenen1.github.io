class Socks {
int x,y;

  void display(float x) {

   push();
    translate(x, 375);
    noStroke();
    fill(#D81111);
    rect(31, this.y + 45, 58, 60);
    rotate(PI / 2.6);
    ellipse(120, this.y - 10, 40, 80);
    pop();

    push();
    translate(x, 375);
    fill(255);
    stroke(0);
    strokeWeight(2);
    rect(26, this.y + 15, 70, 34);
    strokeWeight(1);
    pop();
  }
}
