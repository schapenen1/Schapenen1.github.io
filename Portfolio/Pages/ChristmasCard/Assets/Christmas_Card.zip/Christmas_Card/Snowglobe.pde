class SnowGlobe {
  Song song;
  Scenery scenery;

  int x, y;
  float angle;
  boolean toRight = false;

  // Constructor
  SnowGlobe () {
    song = new Song ();
    scenery = new Scenery ();
  }

  void display() {
    pushMatrix();

    translate(width/2, height/4);
    rotate(radians(angle));

    //Sphere of snowglobe
    fill(#A29ED3);
    stroke(0);
    circle(x, y, 300);
    noStroke();

    //display scenery
    scenery.display();

    //display song when snowglobe is shaked
    fill(0);
    if (toggleCount == maxToggles) {
      song.display();
      song.update();
    }
    //Base of the Snowglobe
    //Has to be last in drawing order, due to the animation
    fill(#5D4301);
    quad(x+120, y+160, x+110, y+100, x-110, y+100, x-120, y+160);

    popMatrix();
  }

  float targetAngle = 20; 
  float rotationSpeed = 0.3;
  int toggleCount = 0;    
  int maxToggles = 3;      

  void movement() {
    if (!start) {
      if (toggleCount >= maxToggles) {
        angle += rotationSpeed;
        if (angle>0) {
          angle = 0;
          return;
        }
      }

      // Adjust angle gradually toward target
      if (toRight && angle > -targetAngle) {
        angle = max(angle - rotationSpeed, -targetAngle); 
      } else if (!toRight && targetAngle > angle) {
        angle = min(angle + rotationSpeed, targetAngle);
      }

      // Check if maximum angle is reached and reverse direction
      if (angle <= -targetAngle && toRight) {
        toRight = false; 
        toggleCount++;   
      } else if (angle >= targetAngle && !toRight) {
        toRight = true;  
        toggleCount++;   
      }
    }
  }

  boolean start = true;

  void start() {
    start=false;
  }
}
