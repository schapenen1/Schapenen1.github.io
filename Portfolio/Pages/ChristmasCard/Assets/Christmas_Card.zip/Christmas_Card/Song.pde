class Song {
  float[] wordX; // Array for random x positions
  float[] wordY; // Array for dynamic y positions
  float[] amplitudes; // Array for unique amplitudes per word
  float lineHeight = 50; // Height between words
  String[] storestrings; // The words from the file
  PFont font;

  // Constructor to initialize the Song
  Song() {
    // Load the file and split into words
    String[] storelines = loadStrings("Jingle Bells.txt");
    String storetext = join(storelines, " ");
    storestrings = split(storetext, " ");


    //Load the font
    font = loadFont("FreestyleScript-Regular-48.vlw");

    // Initialize random x positions and unique amplitudes
    wordX = new float[storestrings.length];
    wordY = new float[storestrings.length];
    amplitudes = new float[storestrings.length];

    for (int i = 0; i < storestrings.length; i++) {
      wordX[i] = random(-100, 50);
      wordY[i] = i * lineHeight -1100;
      amplitudes[i] = random(5, 15);
    }
  }


  void display() {
    fill(255);
    textFont(font, 40);

    // words in reverse order
    for (int i = storestrings.length - 1; i >= 0; i--) {
      // Calculate sinusoidal offset
      float wordOffset = amplitudes[i] * sin(frameCount * 0.05 + i);
      // Calculate reversed index for vertical alignment
      int reversedIndex = storestrings.length - 1 - i;
      // Draw the word at the current position
      text(storestrings[i], wordX[i] + wordOffset, wordY[reversedIndex]);
    }
  }

  // Update method to move words
  void update() {
    //Moving Downwards
    for (int i = 0; i < storestrings.length; i++) {
      wordY[i] += 1;

      // Reset Position
      if (wordY[i] > 150) {
        wordY[i] = -900;
      }
    }
  }
}
