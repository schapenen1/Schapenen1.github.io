class Scenery {
  color house = #9B6030;

  void display () {
    //Pinetree
    pushMatrix();
    translate(10, 0);
    
    fill(#376C1C);
    triangle(-80, 15, -60, -25, -40, 15);
    
    scale(1.5, 1.5);
    translate(20, 25);
    
    fill(#623800);
    rect(-65, 0, 10, 35);
    fill(#376C1C);
    triangle(-80, 15, -60, -25, -40, 15);

    popMatrix();

    //House
    pushMatrix();
    translate(-10, 20);
    pushMatrix();

    scale(1.2, 1.2);
    translate (-10,0 );

    fill(#C63A1E);
    triangle(20, 20, 95, 20, 57.5, -15);

    popMatrix();

    fill(house);
    triangle(20, 20, 95, 20, 57.5, -15);
    rect(20, 20, 75, 35);

    //Door
    fill(0);
    rect(75, 25, 15, 30);
    fill (#EDD33E);
    circle(87, 40, 3);

    //Windows
    fill(#F7DA7A);
    rect( 30, 25, 15, 20);
    rect( 50, 25, 15, 20);
    circle(57.5, 5, 15);
    
    popMatrix();

    //Snow
    fill(255);
    ellipse(0, 94, 200, 50);
    ellipse(45 ,85, 100, 30);
  }
}
