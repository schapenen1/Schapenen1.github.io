//Authors : Lars Gerritsen & Arthur Godthelp

//Movement instructions
//Click the mouse to shake the snow globe

SnowGlobe globe;
Background background;

Match match;
Fire fire;
Socks socks;
Socks [] stocking = new Socks[5];

void setup() {
  size(500, 750);  // Set the size of the window

  background = new Background();
  match = new Match();
  globe = new SnowGlobe();
  fire = new Fire();
  for (int i = 0; i < stocking.length; i++) {
    stocking[i] = new Socks();  // Ensure each element is initialized
  }
}

void draw() {
  background(255);
  globe.display();
  globe.movement();

  background.bricks();
  background.fireplace();
  background.shelf();

  for (int i=0; i<stocking.length; i++) {
    stocking[i].display(i*100);
  }


  if (mouseY >590 || (mouseX > 90 && mouseX< 400 && mouseY > 530)) {
    match.display(mouseX, mouseY);
  }
  fire.display();
}

void mousePressed () {
  if (mouseY<590 && mouseX>0 && mouseX<width) {
    globe.start();
  }
}

void keyPressed() {
  if (mouseY > 720 && mouseX > 130 && mouseX < 365 ) {

    if (key == 'l') {
      fire.update();
    }
  }
}
