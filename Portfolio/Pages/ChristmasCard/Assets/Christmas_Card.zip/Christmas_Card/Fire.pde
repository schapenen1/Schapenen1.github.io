class Fire {
  int i;
  int numPics = 8;
  PImage[] images = new PImage[numPics];
  String imageName;
  int frameDelay = 10;
  int frameCountTracker;
  boolean light = false;

  Fire() {
    for (int j = 0; j < numPics; j++) {
      imageName = "Fire " + (j + 1) + ".png";
      images[j] = loadImage(imageName);
      if (images[j] == null) {
        println("Error: Could not load " + imageName);
        exit();
      }
    }
  }

  void display() {
    if (light) {
      //Logic to determine which images needs to display with a certain delay
      if (frameCountTracker >= frameDelay) {
        i = (i + 1) % numPics;
        frameCountTracker = 0;
      } else {
        frameCountTracker++;
      }

      // Display the current image
      image(images[i], 50, 550, 400, 400);
    }
  }
  void update () {
    light = true;
  }
}
